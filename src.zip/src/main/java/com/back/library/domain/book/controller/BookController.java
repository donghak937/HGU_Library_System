package com.back.library.domain.book.controller;

import com.back.library.domain.book.entity.Book;
import com.back.library.domain.book.entity.BookCopy;
import com.back.library.domain.book.repository.BookCopyRepository;
import com.back.library.domain.book.strategy.BookSearchStrategy;
import com.back.library.domain.book.strategy.CategorySearchStrategy;
import com.back.library.domain.book.strategy.KeywordSearchStrategy;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 도서 검색 전담 컨트롤러
 */
@Controller
@RequestMapping("/book")
@RequiredArgsConstructor
public class BookController {

    private final BookCopyRepository bookCopyRepository;
    private final KeywordSearchStrategy keywordSearchStrategy;
    private final CategorySearchStrategy categorySearchStrategy;
    private BookSearchStrategy searchStrategy;

    public void setSearchStrategy(BookSearchStrategy strategy) {
        this.searchStrategy = strategy;
    }

    /**
     * 검색 UI 화면 렌더링
     */
    @GetMapping("/SearchBookUI")
    public String showSearchBookUI() {
        return "book/SearchBookUI";
    }

    /**
     * 키워드(제목/저자)로 도서 검색 (JSON 반환)
     */
    @GetMapping("/searchBooks")
    @ResponseBody
    public List<Book> searchBooks(@RequestParam String keyword) {
        setSearchStrategy(keywordSearchStrategy);
        return searchStrategy.search(keyword);
    }

    /**
     * 카테고리로 도서 검색 (JSON 반환)
     */
    @GetMapping("/searchBooksByCategory")
    @ResponseBody
    public List<Book> searchBooksByCategory(@RequestParam String category) {
        setSearchStrategy(categorySearchStrategy);
        return searchStrategy.search(category);
    }

    /**
     * 특정 도서 상세 정보 조회 (JSON 반환)
     */
    @GetMapping("/details")
    @ResponseBody
    public ResponseEntity<Book> viewBookDetails(@RequestParam String bookId) {
        return bookRepository.findById(bookId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * 특정 책의 사본 목록 조회 (JSON 반환)
     */
    @GetMapping("/copies")
    @ResponseBody
    public List<BookCopy> getCopiesByBookId(@RequestParam String bookId) {
        return bookCopyRepository.findByBookId(bookId);
    }
}
